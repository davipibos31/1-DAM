﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Practica3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    // --------------------------------------------
    // David Piñuel Bosque
    // Curso DAM
    // Modalidad Presencial
    // Práctica nº 3
    // --------------------------------------------
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();                                              //Inicializa los componentes
        }

        private void btn_Cancelar_Click(object sender, RoutedEventArgs e)
        {
            Close();                                                            //En esta funcion cierra / termina el programa
        }

        private void rb_cliente_Checked(object sender, RoutedEventArgs e)
        {
            if (rb_cliente.IsChecked == true)
            {
                cbx_cliente.IsEnabled = true;                                   //En esta funcion habilita el combobox para el cliente y lo hace visible
                cbx_cliente.Visibility = Visibility.Visible;
                cbx_distribuidor.Visibility = Visibility.Hidden;
                cbx_distribuidor.IsEnabled = false;
            }
        }

        private void rb_Distribuidor_Checked(object sender, RoutedEventArgs e)
        {
            if (rb_Distribuidor.IsChecked == true)
            {
                cbx_distribuidor.IsEnabled = true;
                cbx_distribuidor.Visibility = Visibility.Visible;           //En esta funcion habilita el combobox para el distribuidor y lo hace visible
                cbx_cliente.Visibility = Visibility.Hidden;
                cbx_cliente.IsEnabled = false;
            }
        }

        private void btn_Enviar_Click(object sender, RoutedEventArgs e)
        {
            if (rb_cliente.IsChecked == true)
                MessageBox.Show("INSERT INTO clientes (....) VALUES (...", "SQL Inserción");        // En esta funcion cuando le das a enviar dependiendo de si es cliente o distribuidor manda un mensaje de insercion sql
            else if (rb_Distribuidor.IsChecked == true)
                MessageBox.Show("INSERT INTO distribuidores (...) VALUES (...)", "SQL Inserción");
            barraprogreso();
        }

        private void txt_segundo_apellido_TextChanged(object sender, TextChangedEventArgs e)
        {
            txt_segundo_apellido.MaxLength = 32;
            barraprogreso();                                                                      // En esta funcion pondremos solo la longitud que pide para el textbox
        }

        private void txt_telefono2_TextChanged(object sender, TextChangedEventArgs e)
        {
            txt_telefono2.MaxLength = 9;                                                        // En esta funcion pondremos solo la longitud que pide para el textbox
            barraprogreso();
        }

        private void habilitar(object sender, RoutedEventArgs e)
        {

            if (txt_nombre.Text == "")
            {
                btn_Enviar.IsEnabled = false;
            }
            else if (txt_primer_apellido.Text == "")
            {
                btn_Enviar.IsEnabled = false;
            }
            else if (txt_telefono1.Text == "")
            {
                btn_Enviar.IsEnabled = false;             //En estos if lo que hago es que si esta vacio no habilite el boton pero si lo esta que lo habilite
            }
            else if (txt_correo_electronico.Text == "")
            {
                btn_Enviar.IsEnabled = false;
            }
            else if (txt_direccion.Text == "")
            {
                btn_Enviar.IsEnabled = false;
            }
            else if (txt_codigo_postal.Text == "")
            {
                btn_Enviar.IsEnabled = false;
            }
            else if (txt_poblacion.Text == "")
            {
                btn_Enviar.IsEnabled = false;
            }
            else if (rb_cliente.IsChecked == false && rb_Distribuidor.IsChecked == false)
            {
                btn_Enviar.IsEnabled = false;
            }
            else
            {
                btn_Enviar.IsEnabled = true;
            }
            txt_correo_electronico.MaxLength = 100;
            txt_poblacion.MaxLength = 32;
            txt_direccion.MaxLength = 100;
            txt_codigo_postal.MaxLength = 5;                    // Estas sentencias son las restriciones para los textbox obligatorios 
            txt_telefono1.MaxLength = 9;
            txt_primer_apellido.MaxLength = 32;
            txt_nombre.MaxLength = 32;
            barraprogreso();
        }
        private void txt_telefono1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
                e.Handled = false;                                  //En esta funcion lo que hacemos es que sean solo numeros al teclearlos en el textbox
            else
                e.Handled = true;
        }

        private void txt_telefono2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
                e.Handled = false;                                    //En esta funcion lo que hacemos es que sean solo numeros al teclearlos en el textbox
            else
                e.Handled = true;
        }

        private void barraprogreso()
        {
            int valor = -1;
            pb_Barra.Value = 0;

            if (txt_nombre.Text != "")
            {
                pb_Barra.Value++;
                valor++;
            }
            if (txt_primer_apellido.Text != "")
            {
                pb_Barra.Value++;                           //En esta funcion lo que hcemos es el progreso de la barra conforme vamos rellenando el formulario
                valor++;
            }
            if (txt_segundo_apellido.Text != "")
            {
                pb_Barra.Value++;
                valor++;
            }
            if (rb_cliente.IsChecked == true || rb_Distribuidor.IsChecked == true)
            {
                pb_Barra.Value++;
                valor++;
            }
            if (txt_telefono1.Text != "")
            {
                pb_Barra.Value++;
                valor++;
            }
            if (txt_telefono2.Text != "")
            {
                pb_Barra.Value++;
                valor++;
            }
            if (txt_poblacion.Text != "")
            {
                pb_Barra.Value++;
                valor++;
            }
            if (txt_direccion.Text != "")
            {
                pb_Barra.Value++;
                valor++;
            }
            if (txt_correo_electronico.Text != "")
            {
                pb_Barra.Value++;
                valor++;
            }
            if (txt_codigo_postal.Text != "")
            {
                pb_Barra.Value++;
                valor++;
            }
            if (cbx_cliente.IsLoaded == true || cbx_distribuidor.IsLoaded == true)
            {
                pb_Barra.Value++;
                valor++;
            }
            lbl_Barra_progreso.Content = valor + "/10";       //Espero que te haya gustado he puesto una imagen y la barra de progreso de añadido
        }                                                                           //Un saludo :)
    }
}
