﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_6_6_4
{
    public class CMoto : CVehiculo
    {
        public CMoto()
        {
            this.SetCantidadDeRuedas(2);
        }
    }
}
