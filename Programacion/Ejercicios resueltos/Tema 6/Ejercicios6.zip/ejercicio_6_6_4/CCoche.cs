﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_6_6_4
{
    public class CCoche : CVehiculo
    {
        public CCoche() 
        {
            this.SetCantidadDeRuedas(4);
        }
    }
}
