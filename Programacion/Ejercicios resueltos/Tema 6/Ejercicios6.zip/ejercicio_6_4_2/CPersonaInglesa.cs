﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_6_4_2
{
    class CPersonaInglesa : CPersona
    {
        public string TomandoTe()
        {
            return "Estoy tomando té";
        }
    }
}
