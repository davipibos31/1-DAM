﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_6_4_5
{
    public class CMoto : CVehiculo
    {
    }
}
