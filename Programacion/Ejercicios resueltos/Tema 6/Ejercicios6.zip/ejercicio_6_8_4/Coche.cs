﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ejercicio_6_8_4
{
    class CCoche : CVehiculo
    {
        public CCoche()
        {
            Trace.WriteLine("Construyendo Coche");
        }
    }

}
