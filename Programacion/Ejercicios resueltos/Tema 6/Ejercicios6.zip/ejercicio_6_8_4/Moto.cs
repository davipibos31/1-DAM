﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ejercicio_6_8_4
{
    class CMoto : CVehiculo
    {
        public CMoto()
        {
            Trace.WriteLine("Construyendo Moto");
        }
    }
}
