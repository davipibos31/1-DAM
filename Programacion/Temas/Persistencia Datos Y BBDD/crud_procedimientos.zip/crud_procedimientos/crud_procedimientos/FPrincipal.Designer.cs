﻿namespace crud_procedimientos
{
    partial class FPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mArchivo = new System.Windows.Forms.ToolStripMenuItem();
            this.mArchivoSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.mProductos = new System.Windows.Forms.ToolStripMenuItem();
            this.mProductosProductos = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mArchivo,
            this.mProductos});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(800, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            // 
            // mArchivo
            // 
            this.mArchivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mArchivoSalir});
            this.mArchivo.Name = "mArchivo";
            this.mArchivo.Size = new System.Drawing.Size(60, 20);
            this.mArchivo.Text = "Archivo";
            // 
            // mArchivoSalir
            // 
            this.mArchivoSalir.Name = "mArchivoSalir";
            this.mArchivoSalir.Size = new System.Drawing.Size(180, 22);
            this.mArchivoSalir.Text = "Salir";
            this.mArchivoSalir.Click += new System.EventHandler(this.sAlirToolStripMenuItem_Click);
            // 
            // mProductos
            // 
            this.mProductos.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mProductosProductos});
            this.mProductos.Name = "mProductos";
            this.mProductos.Size = new System.Drawing.Size(73, 20);
            this.mProductos.Text = "Productos";
            // 
            // mProductosProductos
            // 
            this.mProductosProductos.Name = "mProductosProductos";
            this.mProductosProductos.Size = new System.Drawing.Size(180, 22);
            this.mProductosProductos.Text = "Productos...";
            this.mProductosProductos.Click += new System.EventHandler(this.mProductosProductos_Click);
            // 
            // FPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip);
            this.MainMenuStrip = this.menuStrip;
            this.Name = "FPrincipal";
            this.Text = "CRUD C# CON PROCEDIMIENTOS";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem mArchivo;
        private System.Windows.Forms.ToolStripMenuItem mArchivoSalir;
        private System.Windows.Forms.ToolStripMenuItem mProductos;
        private System.Windows.Forms.ToolStripMenuItem mProductosProductos;
    }
}