﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace crud_procedimientos
{
    public partial class FPrincipal : Form
    {
        public FPrincipal()
        {
            InitializeComponent();
        }

        private void sAlirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mProductosProductos_Click(object sender, EventArgs e)
        {
            FProductos fProductos = new FProductos();

            fProductos.ShowDialog();
        }
    }
}
